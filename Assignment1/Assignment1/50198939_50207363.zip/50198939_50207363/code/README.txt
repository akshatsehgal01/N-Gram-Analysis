Contributor 1 - Ms. Saatchi Nandwani
Contributor 2 - Mr. Akshat Sehgal

Please use the concatenated file 'input.txt' as the input file for running the program.

Add the java file WordCountByLength.java to the eclipse project and export as jar file.

Then use either eclipse or terminal to run the mapreduce program.