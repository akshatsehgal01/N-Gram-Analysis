(a) Saatchi Nandwani
    Akshat Sehgal

(b) saatchin@buffalo.edu
    akshatse@buffalo.edu

(c) UB Person # Saatchi Nandwani - 50207363
    UB Person # Akshat Sehgal - 50198939

(d) CCR Job Ids:
    One Reducer - job_1480947435876_0188
    Two Reducer - job_1480947435876_0189

(e) Instructions:
    (i) Create an eclipse mapreduce program and create a jar with the source code provided
   (ii) Use the below command to execute the jar on the input file provided:
        hadoop jar <jar location> TrigramCount <input file location on ccr> <output file to be generated on ccr> <number of reducers>